<!DOCTYPE html>
<html lang="es">
<head>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<style>
@media print { .no-print { display: none; } }
body { background: white !important; color: black !important; }
</style>
</head>
<body onload="window.print()">
<div class="container mt-5">
<h2 class="text-center mb-4">Reporte de Estudiantes Inscritos</h2>
<table class="table table-bordered">
<thead class="table-dark">
<tr>
<th>Estudiante</th>
<th>Email</th>
<th>Curso Inscrito</th>
<th>Fecha</th>
</tr>
</thead>
<tbody>
<?php foreach ($reporte as $r): ?>
<tr>
<td><?php echo $r['nombre']; ?></td>
<td><?php echo $r['email']; ?></td>
<td><?php echo $r['curso']; ?></td>
<td><?php echo $r['fecha_inscripcion']; ?></td>
</tr>
<?php endforeach; ?>
</tbody>
</table>
<button onclick="window.close()" class="btn btn-secondary no-print">Cerrar</button>
</div>
</body>
</html>
