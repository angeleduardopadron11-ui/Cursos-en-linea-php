-- ======================================================
-- SCRIPT DEFINITIVO: LIMPIEZA, ESTRUCTURA Y CONTENIDO
-- ======================================================

-- 1. LIMPIEZA PARA EVITAR CONFLICTOS
-- Borramos en orden inverso por las llaves foráneas
DROP TABLE IF EXISTS `calificaciones`;
DROP TABLE IF EXISTS `lecciones`;
DROP TABLE IF EXISTS `modulos`;

-- 2. ESTRUCTURA DE TABLA CURSOS
CREATE TABLE IF NOT EXISTS `cursos` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `titulo` VARCHAR(150) NOT NULL,
    `descripcion` TEXT,
    `precio` DECIMAL(10, 2),
    `imagen` VARCHAR(255) DEFAULT 'default.jpg',
    `categoria` ENUM('marketing', 'ciberseguridad', 'otros') DEFAULT 'otros',
    `instructor_id` INT DEFAULT NULL,
    `fecha_creacion` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 3. AJUSTE DE USUARIOS
ALTER TABLE `usuarios`
MODIFY COLUMN `password` VARCHAR(255) NOT NULL,
ADD COLUMN IF NOT EXISTS `foto_usuario` VARCHAR(255) DEFAULT 'default.png';

-- 4. NUEVAS ENTIDADES (Con nombres de columnas sincronizados)
CREATE TABLE IF NOT EXISTS `instructores` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `nombre` VARCHAR(100) NOT NULL,
    `datos` TEXT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE `modulos` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `curso_id` INT NOT NULL,
    `titulo` VARCHAR(255) NOT NULL, -- Cambiado de 'nombre' a 'titulo' como pide tu DB
    `orden` INT DEFAULT 0,
    CONSTRAINT `fk_modulos_curso` FOREIGN KEY (`curso_id`) REFERENCES `cursos` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE `lecciones` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `modulo_id` INT NOT NULL,
    `video` VARCHAR(255) DEFAULT NULL,
    `texto` TEXT DEFAULT NULL,      -- Columna 'texto' confirmada para el PHP
    CONSTRAINT `fk_lecciones_modulo` FOREIGN KEY (`modulo_id`) REFERENCES `modulos` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 5. CARGA DE DATOS (Módulos e Introducción a lenguajes)

-- Cursos base
INSERT INTO `cursos` (`id`, `titulo`, `descripcion`, `precio`, `categoria`) VALUES
(1, 'Master en Desarrollo Web', 'De HTML5 hasta SQL. La ruta completa del desarrollador.', 0.00, 'otros')
ON DUPLICATE KEY UPDATE titulo=VALUES(titulo);

-- Módulos para Curso ID 1 (Usando 'titulo')
INSERT INTO `modulos` (`id`, `curso_id`, `titulo`, `orden`) VALUES
(1, 1, 'Módulo 1: Estructura HTML5', 1),
(2, 1, 'Módulo 2: Estilos CSS3', 2),
(3, 1, 'Módulo 3: Lógica JavaScript', 3),
(4, 1, 'Módulo 4: Backend con PHP', 4),
(5, 1, 'Módulo 5: Bases de Datos SQL', 5),
(6, 1, 'Evaluación: Examen Final', 6);

-- Lecciones con párrafos educativos (Usando 'texto')
INSERT INTO `lecciones` (`modulo_id`, `video`, `texto`) VALUES
(1, 'https://www.youtube.com/embed/dQw4w9WgXcQ', 'HTML no es un lenguaje de programación, sino de marcado. Su función es definir la semántica y estructura de la información mediante etiquetas, permitiendo que los navegadores interpreten jerarquías como encabezados y párrafos.'),
(2, 'https://www.youtube.com/embed/dQw4w9WgXcQ', 'CSS3 es el lenguaje encargado de la capa visual. Permite separar el contenido de la presentación, gestionando colores, tipografías y diseños responsivos mediante selectores, el modelo de caja y Flexbox/Grid.'),
(3, 'https://www.youtube.com/embed/dQw4w9WgXcQ', 'JavaScript es el lenguaje que dota de interactividad a la web. Permite manipular el DOM (Document Object Model), gestionar eventos del usuario y realizar peticiones asíncronas, convirtiendo páginas estáticas en aplicaciones dinámicas.'),
(4, 'https://www.youtube.com/embed/dQw4w9WgXcQ', 'PHP es un lenguaje de script del lado del servidor. Su potencia radica en la capacidad de procesar datos antes de enviarlos al navegador, permitiendo la conexión con bases de datos, manejo de sesiones y generación de contenido dinámico.'),
(5, 'https://www.youtube.com/embed/dQw4w9WgXcQ', 'SQL (Structured Query Language) es el estándar para interactuar con bases de datos relacionales. A través de consultas, permite crear, leer, actualizar y borrar información de forma eficiente y segura.'),
(6, NULL, ''); -- Examen final vacío
